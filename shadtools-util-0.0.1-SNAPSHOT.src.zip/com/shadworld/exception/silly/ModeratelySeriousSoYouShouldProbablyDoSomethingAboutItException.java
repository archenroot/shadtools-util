/*    */ package com.shadworld.exception.silly;
/*    */ 
/*    */ import com.shadworld.exception.ShadException;
/*    */ 
/*    */ public class ModeratelySeriousSoYouShouldProbablyDoSomethingAboutItException extends ShadException
/*    */ {
/*    */   public ModeratelySeriousSoYouShouldProbablyDoSomethingAboutItException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ModeratelySeriousSoYouShouldProbablyDoSomethingAboutItException(String message, Throwable cause)
/*    */   {
/* 12 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ModeratelySeriousSoYouShouldProbablyDoSomethingAboutItException(String message)
/*    */   {
/* 17 */     super(message);
/*    */   }
/*    */ 
/*    */   public ModeratelySeriousSoYouShouldProbablyDoSomethingAboutItException(Throwable cause)
/*    */   {
/* 22 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\development\cryptocurrency\crypto-pool-poolserverj\poolserverj-main\etc\lib\lib_non-maven\shadtools-util-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.shadworld.exception.silly.ModeratelySeriousSoYouShouldProbablyDoSomethingAboutItException
 * JD-Core Version:    0.6.2
 */