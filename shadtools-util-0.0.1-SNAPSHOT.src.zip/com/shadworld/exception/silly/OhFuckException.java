/*    */ package com.shadworld.exception.silly;
/*    */ 
/*    */ import com.shadworld.exception.ShadException;
/*    */ 
/*    */ public class OhFuckException extends ShadException
/*    */ {
/*    */   public OhFuckException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public OhFuckException(String message, Throwable cause)
/*    */   {
/* 12 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public OhFuckException(String message)
/*    */   {
/* 17 */     super(message);
/*    */   }
/*    */ 
/*    */   public OhFuckException(Throwable cause)
/*    */   {
/* 22 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\development\cryptocurrency\crypto-pool-poolserverj\poolserverj-main\etc\lib\lib_non-maven\shadtools-util-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.shadworld.exception.silly.OhFuckException
 * JD-Core Version:    0.6.2
 */